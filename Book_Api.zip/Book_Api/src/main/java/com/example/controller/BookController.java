package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.model.Book;
import com.example.service.BookSeviceImpl;

@RestController
@RequestMapping(value={"/book"})
public class BookController {
	
	@Autowired
	BookSeviceImpl bookServiceImpl;
	

	@PostMapping(value="/add")
	public ResponseEntity<String> addBook(@RequestBody() Book book) {
		
		bookServiceImpl.addBook(book);

		return new ResponseEntity<String>("Book added successfuly!!",HttpStatus.CREATED);
		
	}
	
	
	@DeleteMapping(value="/remove/{id}")
	public ResponseEntity<String> deleteById(@PathVariable("id") long id){
				
		Book book = bookServiceImpl.getUserById(id);
		
		if(book == null) {
			return new ResponseEntity<String>("Invalid!!",HttpStatus.NOT_FOUND);
		}
		
		else {
			 bookServiceImpl.deleteBookById(id);
			 return new ResponseEntity<String>("Deleted succesfully!!",HttpStatus.NO_CONTENT);
		}
	}
	
	@PutMapping(value="/update/{id}")
	public ResponseEntity<String> updateById(@PathVariable("id") long id, @RequestBody Book book){
		
		System.out.println("testing: " +id);
		
		Book books = bookServiceImpl.getUserById(book.getId());
		
		if(books == null) {
			return new ResponseEntity<String>("Not available!!",HttpStatus.NOT_FOUND);
		}
		
		//bookServiceImpl.update(donor, donor.getId());
		bookServiceImpl.updateBook(book, book.getId());
		
		return new ResponseEntity<String>("Book updated successfully!!",HttpStatus.CREATED);
		
		
	}

}
