package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Book;
import com.example.repository.BookRepository;

@Service
public class BookSeviceImpl implements BookService {
	
	@Autowired
	BookRepository bookRepo;
	
	@Override
	public void addBook(Book book) {
		
		bookRepo.save(book);
		
	}


	@Override
	public Book getUserById(long id) {
		
		return bookRepo.findById(id).get();
		
	}

	@Override
	public void deleteBookById(long id) {

		bookRepo.deleteById(id);
		
	}

	@Override
	public Book updateBook(Book book, long id) {
		
		return bookRepo.save(book);
		
	}
	
	

}
