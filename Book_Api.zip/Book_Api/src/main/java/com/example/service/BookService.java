package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.model.Book;

@Service
public interface BookService {
	
	public void addBook(Book book);
	
	public Book updateBook(Book book, long id);
	
	public void deleteBookById(long id);
		
	public Book getUserById(long id);
	
	
	
	

}
